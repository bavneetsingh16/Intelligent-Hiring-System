from django.apps import AppConfig


class ResumerankingConfig(AppConfig):
    name = 'resumeranking'
